from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from typing import Optional
import os

app = FastAPI(title="API Prédiction Éligibilité Don Sang")

# Variables globales pour stocker le modèle et les préprocesseurs
model = None
label_encoder = None
scaler = None

class Donneur(BaseModel):
    niveau_etude: int
    genre: int
    taille: float
    poids: float
    situation_matrimoniale: int
    profession: int
    arrondissement: str
    religion: int
    donneur_avant: int
    taux_hemoglobine: float
    age: float
    mois_dernier_don: float
    jours_dernier_don: float

def train_model():
    global model, label_encoder, scaler
    
    # Charger les données
    data = pd.read_csv('data/avec_taille_poids_impute.csv')
    
    # Sélection des features et target
    features = ['niveau_d_etude', 'genre', 'taille', 'poids', 'situation_matrimoniale_sm', 
                'profession', 'arrondissement_de_residence', 'religion', 
                'a_t_il_elle_deja_donne_le_sang', 'taux_d_hemoglobine', 'age',
                'nombre_de_mois_depuis_dd', 'nombre_de_jours_depuis_ddr']
    
    target = 'eligibilite_au_don'
    
    X = data[features]
    y = data[target]
    
    # Encodage de la target
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)
    
    # Séparation train/test
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42
    )
    
    # Normalisation des données
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Entraînement du modèle
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        class_weight='balanced'
    )
    
    model.fit(X_train_scaled, y_train)
    
    # Évaluation
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    
    return {
        "status": "Modèle entraîné avec succès",
        "accuracy": accuracy,
        "classes": list(label_encoder.classes_)
    }

@app.on_event("startup")
async def startup_event():
    """Entraîne le modèle au démarrage de l'API"""
    result = train_model()
    print(f"Modèle entraîné avec une précision de {result['accuracy']:.2f}")

@app.post("/predict")
async def predict(donneur: Donneur):
    if model is None or label_encoder is None or scaler is None:
        raise HTTPException(status_code=503, detail="Modèle non initialisé")
    
    # Convertir les données en DataFrame
    data = pd.DataFrame([dict(donneur)])
    
    # Prétraitement des données
    try:
        data_scaled = scaler.transform(data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Erreur de prétraitement: {str(e)}")
    
    # Prédiction
    try:
        prediction = model.predict(data_scaled)
        prediction_proba = model.predict_proba(data_scaled)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur de prédiction: {str(e)}")
    
    # Décodage de la prédiction
    prediction_label = label_encoder.inverse_transform(prediction)[0]
    
    return {
        "prediction": prediction_label,
        "probabilite": {
            "eligible": float(prediction_proba[0][1]),
            "non_eligible": float(prediction_proba[0][0])
        }
    }

@app.get("/retrain")
async def retrain_model():
    """Endpoint pour réentraîner le modèle à la demande"""
    try:
        result = train_model()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de l'entraînement: {str(e)}")

@app.get("/")
async def root():
    return {
        "message": "API de prédiction d'éligibilité au don de sang",
        "status": "Modèle prêt" if model is not None else "Modèle non initialisé"
    }